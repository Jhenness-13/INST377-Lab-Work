const ltetromino = 'firstshape';
const ztetromino = 'Secondshape';
const otetromino = 'thirdShape';
const itetromino = 'fourthShape';
const tTetromino = 'fifthShape';

const tetrominoes = [ltetromino, ztetromino, otetromino, itetromino, tTetromino];

console.log(tetrominoes[0]);
